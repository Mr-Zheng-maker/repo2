//============================================================================
// Name        : stl30_repo.cpp
// Author      : ted
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <map>

int main() {
	std::cout << "using SGI STL map .." << std::endl;
	stdd::map<int, int> sgi_map;
	return 0;
}
